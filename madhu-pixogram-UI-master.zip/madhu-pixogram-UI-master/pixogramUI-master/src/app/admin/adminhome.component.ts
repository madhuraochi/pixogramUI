import { Component } from '@angular/core';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['/../app.component.css']
})
export class AdminHomeComponent {
  title = 'AdminHome';
}
